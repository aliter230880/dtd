package com.dtdusa.dtd_verification

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
